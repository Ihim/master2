package wait_notify;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Processor extends Thread{

public static final String ANSI_RESET = "\u001B[0m";
public static final String ANSI_BLACK = "\u001B[30m";
public static final String ANSI_RED = "\u001B[31m";
public static final String ANSI_GREEN = "\u001B[32m";
public static final String ANSI_YELLOW = "\u001B[33m";
public static final String ANSI_BLUE = "\u001B[34m";
public static final String ANSI_PURPLE = "\u001B[35m";
public static final String ANSI_CYAN = "\u001B[36m";
public static final String ANSI_WHITE = "\u001B[37m";
    String name;
    String type;
    int nbr=0;
    String [] tab = new String [50];
    public Processor(String x, String y ){
    this.type=x;
    this.name=y;
    
    }
    public Processor(String [] x ){
    
        for (int i = 0; i < x.length; i++) {
            if (!x[i].isEmpty()){this.nbr++;
            this.tab[i]=x[i];
            };
            
        }
        
        System.out.println(ANSI_GREEN+" Nombre de threads = "+ANSI_RESET+this.nbr);
        System.out.println(ANSI_RED+" Les threads de couleur 'Rouge'        "+ANSI_RESET+" : Sont les threads consommateurs dans l' etat ' Wait ' ! ");
        System.out.println(ANSI_PURPLE+" Les threads de couleur 'Mauve'        "+ANSI_RESET+" : Sont les threads consommateurs dans l' etat ' Apres Wait ' ! ");
        System.out.println(ANSI_BLUE+" Les threads de couleur 'Bleu Foncé'   "+ANSI_RESET+" : Sont les threads Producteurs dans l' etat ' Wait' ! ");
        System.out.println(ANSI_CYAN +" Les threads de couleur 'Bleu Claire'  "+ANSI_RESET+" : Sont les threads producteurs dans l' etat ' Apres Wait' ! ");
        System.out.println(" Les threads de couleur 'Noir'         "+ANSI_RESET+" : Sont les threads consommateurs/producteurs  normal ! ");
    System.out.println("\n\n\n");
    }
    synchronized public void produce (String nom) throws IndexOutOfBoundsException, InterruptedException {
      Thread.sleep(200);
    synchronized (this){
        boolean test = true;
       while(Wait_Notify.buffer== Wait_Notify.max){
           if(test)
           System.out.println(ANSI_BLUE+"Le producteur  "+nom+" : Je veux produire l' element "+(Wait_Notify.id_produce +1 )+ " le buffer est plein !"+ANSI_GREEN+"                        Buffer = "+Wait_Notify.buffer+ANSI_BLUE+"       Besoin de Consomateurs !!"+ANSI_RESET);
           test=false;
           wait();
       
       }
            Wait_Notify.id_produce++;
            if(test){
            System.out.println("Le producteur  "+nom+" : J' ai produis l' element "+Wait_Notify.id_produce+ANSI_GREEN+"                                                 Buffer = "+(Wait_Notify.buffer+1)+ANSI_RESET);
            }else
            {
            System.out.println(ANSI_CYAN+"Le producteur  "+nom+" : oooooooofff en fin ..... !! , J' ai produis l' element "+Wait_Notify.id_produce+ANSI_GREEN+"                   Buffer = "+(Wait_Notify.buffer+1)+ANSI_RESET);        
                    }
            Wait_Notify.buffer++;
            notify();

    } 
    }
    
    
    synchronized public void consume(String nom) throws InterruptedException{
    Scanner scanner = new Scanner(System.in);
   Thread.sleep(200);
    synchronized(this){
        if(Wait_Notify.buffer > 0){
            Wait_Notify.id_consome++;
        System.out.println("Le consomateur "+nom+" : J' ai consommé l' element "+Wait_Notify.id_consome+ANSI_GREEN+"                                                Buffer = "+(Wait_Notify.buffer-1)+ANSI_RESET);
        Wait_Notify.buffer--;
        }else
        {
        System.out.println(ANSI_RED+"Le consomateur "+nom+" : Je veux consommer  mais le buffer est est vide !"+ANSI_GREEN+"                           Buffer = "+Wait_Notify.buffer+ANSI_RED+"       Besoin de Producteurs !!"+ANSI_RESET);
        //notify();
        while(Wait_Notify.buffer == 0){wait();}
        Wait_Notify.id_consome++;
        System.out.println(ANSI_PURPLE+"Le consomateur "+nom+" : ooooofff en fin .... !! , J' ai consommé l' element "+Wait_Notify.id_consome+ANSI_GREEN+"                      Buffer = "+(Wait_Notify.buffer-1)+ANSI_RESET);
        Wait_Notify.buffer--;
        }
      notify();

    }
    

    
    }
    
    
    
  
    public void run (){
   
        Thread [] x = new Thread[40];
        for (int i = 0; i < this.nbr; i++) {
            String object = tab[i];
            if ((tab[i].charAt(0)=='C')||(tab[i].charAt(0)=='c'))          
            {
                                x[i]=new Thread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                                                                   //Thread.sleep(1000);
                                                                    consume(object);
                                                                } catch (IndexOutOfBoundsException ex) {
                                                                    Logger.getLogger(Wait_Notify.class.getName()).log(Level.SEVERE, null, ex);
                                                                } catch (InterruptedException ex) {
                                                                    Logger.getLogger(Wait_Notify.class.getName()).log(Level.SEVERE, null, ex);
                                                                }
                                                            }
                                                        });
            }else
            if ((tab[i].charAt(0)=='P')||(tab[i].charAt(0)=='p'))
            {
                                            x[i]=new Thread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                   // Thread.sleep(1000);
                                                                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                                                                   produce(object);
                                                                } catch (IndexOutOfBoundsException ex) {
                                                                    Logger.getLogger(Wait_Notify.class.getName()).log(Level.SEVERE, null, ex);
                                                                } catch (InterruptedException ex) {
                                                                    Logger.getLogger(Wait_Notify.class.getName()).log(Level.SEVERE, null, ex);
                                                                }
                                                            }
                                                        });
            
            
            }
            else {
                Scanner scanner = new Scanner (System.in);
                while (true){
                System.out.println("Erreur :");
                System.out.println("        Les threads doivent commencés par 'C' ou 'P' ");
                System.out.println("        Trouvé  :   '"+ tab[i].charAt(0)+"' !    Verifier  le Thread numero = "+(i+1)+"   ( "+object+" )");
                String one =object,two=object;
                System.out.println("Essayé avec  C"+object+" /  P"+object );
                scanner.nextLine();
                }
                
                
            }
            
        }
        
        for (int i = 0; i < this.nbr; i++) {

            try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
                Logger.getLogger(Processor.class.getName()).log(Level.SEVERE, null, ex);
            }
            x[i].start();
            try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
                Logger.getLogger(Processor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
   
    }
   
}
