/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wait_notify;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MIHI Aissa
 */
public class Wait_Notify {
    static int max = 5;
    static int buffer =0;
    static int id_produce=0;
    static int id_consome=0;
    static public void Initialisation(){
        do{
                    Scanner scanner = new Scanner (System.in);
        System.out.print("Entrer la taille du buffer = ");
        Wait_Notify.max=scanner.nextInt();
        do{
        System.out.print("Entrer l' etat initial du buffer 'Nombre d' elemnts initials' = ");
        Wait_Notify.buffer=scanner.nextInt();
        if(Wait_Notify.buffer>Wait_Notify.max){
            System.out.println("L' etat initial ne doit pas etre plus grande que la taille de buffer : "+Wait_Notify.max);        
        }
        
        }while(Wait_Notify.buffer>Wait_Notify.max);
        if((Wait_Notify.buffer<0)||(Wait_Notify.max<0)){
        
            System.out.println("Erreur  :  Les valeurs doit etre positives");
        }
        
        }while((Wait_Notify.buffer<0)||(Wait_Notify.max<0));


        System.out.println("\n\n");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
Initialisation();
// li yebda b 'c' houwa consomateur w 'p' producteur t3emerhom fel vecteur f heda !!!
       // String []f={"c1","c2","p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11","c3","c18","c19","c100"};
String []f={"c1","c2","p1","k2","p3","p4","p5","p6","p7","p8","p9","p10","p11","c3"};
       Processor p = new Processor(f); 

p.start();
        


          
    }
    
}
